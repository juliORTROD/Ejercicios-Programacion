/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Exercici2Recursivitat;

import java.util.Scanner;

/**
 *
 * @author juor7066
 */
public class RecursivitatEx3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Indica el numero de files: ");
        int files = sc.nextInt();
        
        calculaBombetes(files);
        System.out.println("A l'arbe hi han: " + calculaBombetes(files) + " bombetes.");
     
    }
    
    public static int bombetesPerFila(int fila){
        int bombetes;
        if (fila==0) {
            bombetes=0;
            return bombetes;
        }
        else if (fila==1) {
            bombetes=1;
            return bombetes;
        }
        else if (fila>1) {
            bombetes = 2 + bombetesPerFila(fila-1);
            return bombetes;
        }
        return -1;
    }
    
    public static int calculaBombetes(int bombetaPerFila){
        int sumaDeBombetes;
        if (bombetaPerFila==0) {
            sumaDeBombetes = 0;
            return sumaDeBombetes;
        }
        else if (bombetaPerFila>1) {
            sumaDeBombetes = bombetaPerFila + 2 + bombetesPerFila(bombetaPerFila-1);
            return sumaDeBombetes;
        }
        return bombetaPerFila -1;
    }
    }
    


